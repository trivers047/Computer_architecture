#include "stdio.h"

void main(int argc, char** argv) {
  unsigned int x;
  __builtin_prefetch(&x);
  printf("%d\n", x);		     
}
