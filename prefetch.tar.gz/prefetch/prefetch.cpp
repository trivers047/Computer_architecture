#include <iostream>
#include <iomanip>
#include <fstream>
#include <unistd.h>
#include "pin.H"

KNOB<string> KnobOutputFile(KNOB_MODE_WRITEONCE,         "pintool",
    "o", "prefetch.out", "specify file name for insmix profile ");

static UINT64 inscount = 0;
static UINT64 precount = 0;

VOID count_instructions(UINT32 i, UINT32 p) { 
  inscount += i;
  precount += p;
}

INT32 Usage()
{
    cerr <<
        "This pin tool computes a static and dynamic instruction mix profile\n"
        "\n";
    cerr << KNOB_BASE::StringKnobSummary();
    cerr << endl;
    return -1;
}

VOID Trace(TRACE trace, VOID *v)
{
    for (BBL bbl = TRACE_BblHead(trace); BBL_Valid(bbl); bbl = BBL_Next(bbl))
    {
      UINT32 np = 0;
      for (INS ins = BBL_InsHead(bbl); INS_Valid(ins); ins = INS_Next(ins)) {
	if (INS_IsPrefetch(ins)) {
	  np++;
	  cout << INS_Disassemble(ins) << endl;
	}
      }
      
      BBL_InsertCall(bbl, IPOINT_BEFORE, (AFUNPTR)count_instructions, 
		     IARG_UINT32, BBL_NumIns(bbl), 
		     IARG_UINT32, np, 
		     IARG_END);
    }
}

VOID Fini(int, VOID * v)
{
    string filename;
    std::ofstream out;

    filename =  KnobOutputFile.Value();
    out.open(filename.c_str());
    out << "Ins count: " << inscount << endl;
    out << "Pre count: " << precount << endl;
    out << "Pct: " << ((float)precount/inscount)*100 << endl;
    out.close();
}
int main(int argc, CHAR *argv[])
{
    PIN_InitSymbols();
    if (PIN_Init(argc, argv))
    {
        return Usage();
    }

    TRACE_AddInstrumentFunction(Trace, 0);
    PIN_AddFiniFunction(Fini, 0);

    // Never returns
    PIN_StartProgram();

    return 0;
}
